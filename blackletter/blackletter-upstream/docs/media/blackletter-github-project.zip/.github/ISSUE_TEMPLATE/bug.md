---
name: Bug
about: Something broke
title: "[BUG] "
labels: ["type:bug"]
---
## Expected
## Actual
## Steps to Reproduce
## Logs / Screenshots
## Severity
