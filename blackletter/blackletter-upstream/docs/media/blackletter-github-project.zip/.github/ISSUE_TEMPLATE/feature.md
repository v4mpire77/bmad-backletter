---
name: Feature
about: User story with acceptance criteria
title: "[FEAT] "
labels: ["type:feature"]
---
## User Story
As a ___, I want ___ so that ___.

## Acceptance Criteria
- [ ] 
- [ ] 

## Notes
UX, data model, security, telemetry.

## Links
Related EPIC: #
