# Security Policy
- Report vulnerabilities via private email/contact.
- Secrets must never be committed. Use environment variables or a vault.
- High-severity rule changes require dual approval.
