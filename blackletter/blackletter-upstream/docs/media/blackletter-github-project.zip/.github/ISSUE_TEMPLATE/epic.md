---
name: Epic
about: Business outcome spanning multiple features
title: "[EPIC] "
labels: ["type:epic"]
---
## Outcome
Describe the business goal and KPIs (e.g., TTV < 14d, CAC -30%).

## Scope
- Features:
- Domains:
- Integrations:

## Risks & Assumptions

## Acceptance Criteria / DoD
- [ ] KPI wired to dashboard
- [ ] Release notes planned
