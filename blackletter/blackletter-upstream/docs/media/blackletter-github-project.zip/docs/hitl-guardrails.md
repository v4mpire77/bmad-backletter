# HITL Guardrails

- Red-severity flags require human approval before marking complete.
- Explainability: show rule, why flagged, confidence, comparable examples.
- Duty-of-care boundaries surfaced in UI/API responses.
