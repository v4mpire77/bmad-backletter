# Contributing
- Use Conventional Commits.
- Link issues in PRs.
- Add/Update tests for rules touching high severity.
- Do not merge if Assurance metrics regress.
